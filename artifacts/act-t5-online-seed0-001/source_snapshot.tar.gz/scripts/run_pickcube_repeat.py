"""One finite independent task/seed, using the recorded development protocol.

Eight sequential jobs share the existing GPU lock and batch budget. No retries,
checkpoint selection, parameter search, or final-test access.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
TEMPLATES=[
    ('bc','e1-bc-full-003'),('a','e2-sac-a-full-002'),
    ('b','e2-sac-b-full-001'),('c','e3-sac-c-full-001'),
    ('wm','e4-wm-full-001'),('value','e6-value-preheat-001'),
    ('u0','e6-u0-full-001'),('c-continue','e3-sac-c-continue-full-001'),
]


def training_seconds_left():
    budget=json.loads((ROOT/'research_state.json').read_text())['budget']
    return budget['gpu_hours_limit']*3600-budget['gpu_job_seconds_used']-budget['final_evaluation_reserve_seconds']


def plan(seed,task='PickCube-v1'):
    tag,protocol_name={'PickCube-v1':('pick','pickcube_protocol.json'),
        'StackCube-v1':('stack','stackcube_protocol.json'),
        'PegInsertionSide-v1':('peg','peg_protocol.json')}[task]
    protocol=json.loads((ROOT/'configs'/protocol_name).read_text())
    data_id={'pick':'e0-pickcube-gpu-replay-full-003',
             'stack':'e0-stack-gpu-replay-full-001',
             'peg':'e0-peg-gpu-replay-full-002'}[tag]
    dataset=f"data/replay/{data_id}/trajectory.state.{protocol['control_mode']}.physx_cuda.h5"
    audit=f'artifacts/{data_id}/dataset-audit.json'
    replacements={old:f'{tag}-seed{seed}-{name}-001' for name,old in TEMPLATES}
    jobs=[]
    for name,old in TEMPLATES:
        template=json.loads((ROOT/'artifacts'/old/'manifest.json').read_text())
        command=template['command'].copy()
        for i,arg in enumerate(command):
            for original,new in replacements.items():
                if arg==original or arg.endswith('/'+original) or '/'+original+'/' in arg:
                    arg=arg.replace(original,new)
            command[i]=arg
        if '--seed' in command:command[command.index('--seed')+1]=str(seed)
        else:command+=['--seed',str(seed)]
        for option,value in {'--env-id':task,'--control-mode':protocol['control_mode'],
            '--max-episode-steps':str(protocol['max_episode_steps']),
            '--num-eval-steps':str(protocol['max_episode_steps']),
            '--demo-path':dataset,'--expert-dataset':dataset,
            '--split-manifest':audit,'--expert-audit':audit}.items():
            if option in command:command[command.index(option)+1]=value
        jobs.append(dict(id=replacements[old],seconds=template['limit_seconds'],command=command))
    return jobs


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--seed',type=int,choices=[0,1,2,3,4],required=True)
    parser.add_argument('--task',choices=['PickCube-v1','StackCube-v1','PegInsertionSide-v1'],default='PickCube-v1')
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--plan-only',action='store_true')
    args=parser.parse_args()
    jobs=plan(args.seed,args.task)
    if args.plan_only:
        args.output.write_text(json.dumps(jobs,indent=2)+'\n');return
    args.output.mkdir(parents=True,exist_ok=False)
    (args.output/'plan.json').write_text(json.dumps(jobs,indent=2)+'\n')
    record=dict(task=args.task,seed=args.seed,phase='running',completed=[],current=None)
    def save():
        temp=args.output/'status.tmp';temp.write_text(json.dumps(record,indent=2)+'\n')
        temp.replace(args.output/'status.json')
    try:
        for job in jobs:
            remaining=training_seconds_left();assert remaining>0,'Training budget exhausted; preserve final evaluation reserve'
            record['current']=job['id'];save()
            subprocess.run([sys.executable,'scripts/run_experiment.py','--id',job['id'],
                            '--seconds',str(min(job['seconds'],remaining)),'--',*job['command']],cwd=ROOT,check=True)
            record['completed'].append(job['id'])
        record.update(phase='completed',current=None)
    except BaseException as error:
        record.update(phase='failed',error=repr(error));raise
    finally:save()


if __name__=='__main__':main()
